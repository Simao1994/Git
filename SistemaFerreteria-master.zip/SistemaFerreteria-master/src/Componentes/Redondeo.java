package Componentes;

public class Redondeo {
    
    public static double redondear(double numero)
    {
        return Math.rint(numero*100)/100;
    }
    
}
